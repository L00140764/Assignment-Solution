/**
 * Author: Dean Golding
 * Class: Software Implementation
 * Instructor: Maria Boyle
 * Description: Developed for the Flight Booking System Repeat CA
 */

package ie.lyit.flight;

public class Name {
private String title;
private String firstName;
private String surname;
public Name()
	{
		this.title=null;
		this.firstName=null;
		this.surname=null;
	}
	public Name(String title, String firstName, String surname)
	{
		this.title=title;
		this.firstName=firstName;
		this.surname=surname;
	}
	public Name(Object obj)
	{
		if (obj instanceof Name)
		{
			this.title=((Name) obj).getTitle();
			this.firstName=((Name) obj).getFName();
			this.surname=((Name) obj).getSName();
		}
	}
	//Getters
	public String getTitle()
	{
		return title;
	}
	public String getFName()
	{
		return firstName;
	}
	public String getSName()
	{
		return surname;
	}
	//Setters
	public void setTitle(String title)
	{
		this.title=title;
	}
	public void setFName(String firstName)
	{
		this.firstName=firstName;
	}
	public void setSName(String surname)
	{
		this.surname=surname;
	}
	
	public boolean isFemale()
	{
		if(title.equals("Mrs")||title.equals("Miss")||title.equals("Ms"))
			return true;
		return false;
	}
	public String toString()
	{
		return (""+title+". "+firstName+" "+surname);
	}
	public boolean equals(Object obj)
	{
		Name that;
		if(obj instanceof Name )
			that=(Name)obj;
		else
		return false;
		return (this.title.equals(that.title)&&this.firstName.equals(that.firstName)&&this.surname.equals(that.surname));
	}
	
}
