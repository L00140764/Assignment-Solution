/**
 * Author: Dean Golding
 * Class: Software Implementation
 * Instructor: Maria Boyle
 * Description: Developed for the Flight Booking System Repeat CA
 */

package ie.lyit.flight;
public class Passenger extends Person {
	private Name name;
	private Date dateOfBirth;
	private int noBags;
	private boolean priorityBoarding;
	public Passenger()
	{
		this.name=null;
		this.dateOfBirth=null;
		this.noBags=0;
		this.priorityBoarding=false;
	}
	public Passenger(Name name, Date dateOfBirth, int noBags, boolean priorityBoarding)
	{
		this.name=name;
		this.dateOfBirth=dateOfBirth;
		this.noBags=noBags;
		this.priorityBoarding=priorityBoarding;
	}
	//Getters
	public Name getName()
	{
		return name;
	}
	public Date getDOB()
	{
		return dateOfBirth;
	}
	public int getNoBags()
	{
		return noBags;
	}
	public boolean getPriorityBoarding()
	{
		return priorityBoarding;
	}
	//Setters
	public void setName(Name name)
	{
		this.name = name;
	}
	public void setDOB(Date dateOfBirth)
	{
		this.dateOfBirth = dateOfBirth;
	}
	public void setNoBags(int noBags)
	{
		this.noBags = noBags;
	}
	public void setPriorityBoarding(boolean priorityBoarding)
	{
		this.priorityBoarding = priorityBoarding;
	}
	public String toString()
	{
		return ("name: "+name+". DOB: "+dateOfBirth+". Number of Bags: "+noBags+". Priority: "+priorityBoarding);	
	}
	public boolean equals(Object obj)
	{
		Passenger that;
		if(obj instanceof Passenger )
			that=(Passenger)obj;
		else
			return false;
		
		return (this.name.equals(that.name)&&this.dateOfBirth.equals(that.dateOfBirth)&&this.noBags==that.noBags&&this.priorityBoarding==that.priorityBoarding);
	}
	
}
