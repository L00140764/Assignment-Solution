/**
 * Author: Dean Golding
 * Class: Software Implementation
 * Instructor: Maria Boyle
 * Description: Developed for the Flight Booking System Repeat CA
 */
package ie.lyit.flight;
import java.io.Serializable;
public class Date implements Serializable{
private int day;
private int month;
private int year;
public Date()
	{
		this.day=0;
		this.month=0;
		this.year=0;
	}
	public Date(int day, int month, int year) throws IllegalArgumentException
	{
		if(day<1||day>31)
			throw new IllegalArgumentException("Invalid Day choice");
		else
			this.day=day;		
		if(month<1||month>12)
			throw new IllegalArgumentException("Invalid Months choice");
		else
			this.month=month;
		if(year<1980)
			throw new IllegalArgumentException("Invalid Year choice");
		else
			this.year=year;
	}
	public int getDay()
	{
		return day;
	}
	public int getMonth()
	{
		return month;
	}
	public int getYear()
	{
		return year;
	}
	//Setters
	public void setDay(int day) throws IllegalArgumentException
	{
		if(day<1||day>31)
			throw new IllegalArgumentException("Invalid Day choice");
		else
			this.day=day;
	}
	public void setMonth(int month)
	{
		if(month<1||month>12)
			throw new IllegalArgumentException("Invalid Month choice");
		else
			this.month=month;
	}
	public void setYear(int year)
	{
		if(year<1980)
			throw new IllegalArgumentException("Invalid Year choice");
		else
			this.year=year;
	}
	public String toString()
	{
		return (""+day+"/"+month+"/"+year);
	}
	public boolean equals(Object obj)
	{
		Date that;
		if(obj instanceof Date )
			that=(Date)obj;
		else
			return false;
         
		return (this.day==that.day && this.month==that.month&&this.year==that.year);
	}
	
}
