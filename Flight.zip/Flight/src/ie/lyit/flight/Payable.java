/**
 * Author: Dean Golding
 * Class: Software Implementation
 * Instructor: Maria Boyle
 * Description: Developed for the Flight Booking System Repeat CA
 */

package ie.lyit.flight;
public interface Payable {
	public abstract double calculateWage(double taxPercentage);
	double incrementSalary(double incrementAmount);
}