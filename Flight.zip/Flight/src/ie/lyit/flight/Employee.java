package ie.lyit.flight;
import java.io.Serializable;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Employee extends Person implements Payable, Serializable {
private Date startDate;	// Employee has name&dateOfBirth from Person		
private double salary;	// AND startdate,salary, & number
private int number;

	private static int nextNumber=1000;	// static for unique number - starts off at 1000    
	private final double MAX_SALARY = 150000.00;
   public Employee(){
    	super();
    	startDate=new Date();
 		salary=0.0;
		// Set number to static nextNumber before incrementing nextNumber
 		number=nextNumber++;
    }
    public Employee(String t, String fN, String sn, 
    		        int d, int m, int y,
    		        Date startDate, double salary){
       // Call super class constructor - Passing parameters required by Person ONLY!
	   super(t, fN, sn, d, m, y);
	   // And then initialise Employees own instance variables
	   this.startDate=startDate;	// Set instance variable to parameter
	   this.salary=salary;
		// Set number to static nextNumber before incrementing nextNumber
	   number = nextNumber++;						
	}
	// OVERRIDING the Person toString() method!
	// Calling Persons toString() method, and adding additional bits
	@Override
    public String toString(){
		return number + " " + super.toString() + " �" + salary;
	}
	// equals() method
	// ==> Called when comparing an object with another object, 
	//     e.g. - if(e1.equals(e2))				
	// ==> Probably sufficient to compare customer numbers as they're unique
	@Override
	public boolean equals(Object obj){
		Employee eObject;
		if (obj instanceof Employee)
		   eObject = (Employee)obj;
		else
		   return false;
	    return(this.number==eObject.number);
	}
	public void setStartDate(Date startDate){
		this.startDate=startDate;
	}
	public Date getStartDate(){
		return startDate;
	}	
	public void setSalary(int salary){
		this.salary=salary;
	}
	public double getSalary(){
		return salary;
	}
	public Name getName() {
		return super.name;
	}
	public void setName(Name name)
	{
		this.name = name;
	}
	//getters
	public int getNumber(){
		return number;
	}	
	public double calculateWage(double taxPercentage) {
		// calculate and return the wage as salary/12 less taxPercentage
		double wage=salary/12;
		wage -= (wage * (taxPercentage/100));
		return wage;
	}
   
	public double incrementSalary(double incrementAmount) {

		salary += incrementAmount;
		
		if(salary > MAX_SALARY)
			salary = MAX_SALARY;
		   return salary;
	}
	
	//read change this shit nigger
	public void read(){
		String[] title = {"Mr","Mrs","Ms","Dr"};
		String[] days = {"1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30","31"};
		String[] months = {"1","2","3","4","5","6","7","8","9","10","11","12"};
		String[] years = {"1980","1981","1982","1983","1984","1985","1986","1987","1988","1989","1990","1991","1992",	"1993",	"1994",	"1995",	"1996",	"1997",	"1998",	"1999",	"2000",	"2001",	"2002",	"2003",	"2004",	"2005",	"2006",	"2007",	"2008",	"2009",	"2010",	"2011",	"2012",	"2013",	"2014",	"2015",	"2016",	"2017",	"2018",	"2019"};
	      JComboBox txtnameTitle new JComboBox(title);
	      JTextField txtFname = new JTextField();
	      JTextField txtSname = new JTextField();
	      
	      JComboBox txtBirthDay = new JComboBox(days);
	      JComboBox txtBirthMonth = new JComboBox(months);
	      JComboBox txtBirthYear = new JComboBox(years);
	      
	      JComboBox txtStartDay = new JComboBox(days);
	      JComboBox txtStartMonth = new JComboBox(months);
	      JComboBox txtStartYear = new JComboBox(years);
	      
	      JTextField txtSalary = new JTextField();

	      Object[] message = {
	          "Title:", txtnameTitle,
	          "First name:", txtFname,
	          "Last Name:", txtSname,
	          "Birth day[integer]:", txtBirthDay,
	          "Birth month[integer]:", txtBirthMonth,
	          "Birth year[integer]:", txtBirthYear,
	          "Start day[integer]:", txtStartDay,
	          "Start month[integer]:", txtStartMonth,
	          "Start year[integer]:", txtStartYear,
	          "salary:", txtSalary,
	      };

	      int option = JOptionPane.showConfirmDialog(null, message, "Enter employee details", JOptionPane.OK_CANCEL_OPTION);

	      if (option == JOptionPane.OK_OPTION){
	    	  String titletxt= txtnameTitle.getSelectedItem().toString();
	    	  super.name = new Name(titletxt, txtFname.getText(), txtSname.getText());
	    	  String t1=txtBirthDay.getSelectedItem().toString(), t2=txtBirthMonth.getSelectedItem().toString(),t3=txtBirthYear.getSelectedItem().toString();
	    	  int d=Integer.parseInt(t1), m=Integer.parseInt(t2), y=Integer.parseInt(t3);
	    	  super.dateOfBirth = new Date(d, m, y);
	    	  t1=txtStartDay.getSelectedItem().toString(); t2=txtStartMonth.getSelectedItem().toString(); t3=txtStartYear.getSelectedItem().toString();
	    	  d=Integer.parseInt(t1); m=Integer.parseInt(t2); y=Integer.parseInt(t3); 
	    	  super.dateOfBirth = new Date(d, m, y);    	  
	    	  //this.salary=txtSalary.getText()  
	      }   
		}
	
}
