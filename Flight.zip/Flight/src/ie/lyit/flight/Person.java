/**
 * Author: Dean Golding
 * Class: Software Implementation
 * Instructor: Maria Boyle
 * Description: Developed for the Flight Booking System Repeat CA
 */
package ie.lyit.flight;

public abstract class Person {
	protected Name name;
	protected Date dateOfBirth;
	public Person() {
		name = new Name();
		dateOfBirth = new Date();
	}
	public Person(Name name, Date date) {
		this.name = name;
		this.dateOfBirth = date;
	}
	public Person(String t, String f, String s, int d, int m, int y) {
		this.name = new Name(t, f, s);
		this.dateOfBirth = new Date(d, m, y);
	}
	public Person(Name name, int d, int m, int y) {
		this.name = name;
		this.dateOfBirth = new Date(d, m, y);
	}
	public Person(String t, String f, String s, Date date) {
		this.name = new Name(t, f, s);
		this.dateOfBirth = date;
	}
	public String toString() {
		return name.toString() +", "+dateOfBirth.toString();
	}
	public boolean equals(Object obj)
	{
		Person that;
		if(obj instanceof Person )
			that=(Person)obj;
		else
			return false;
		
		return (this.name.equals(that.name)&&this.dateOfBirth.equals(that.dateOfBirth));
	}
}
