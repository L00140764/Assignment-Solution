/**
 * Author: Dean Golding
 * Class: Software Implementation
 * Instructor: Maria Boyle
 * Description: Developed for the Flight Booking System Repeat CA
 */
 
package ie.lyit.tester;
import ie.lyit.flight.Passenger;
import ie.lyit.flight.Date;
import ie.lyit.flight.Name;
public class PassengerTester {

	public static void main(String[] args) {
		Date meDOB = new Date(13, 9, 1996);
		Passenger me = new Passenger();
		me.setDOB(meDOB);
		Name myName = new Name("Mr.", "Dean", "Golding");
		Name notMyName = new Name("Mrs.", "Deab", "Folding");
		me.setName(myName);
		me.setNoBags(5);
		me.setPriorityBoarding(true);
		meDOB.setDay(13);
		meDOB.setMonth(9);
		meDOB.setYear(1996);
		Passenger notMe = new Passenger(notMyName,meDOB, 9, false);
		System.out.print(me.toString()+"\n"+notMe.toString()+"\n");
		System.out.print(me.equals(notMe));
		
		
	}

}
