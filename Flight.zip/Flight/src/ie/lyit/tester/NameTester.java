/**
 * Author: Dean Golding
 * Class: Software Implementation
 * Instructor: Maria Boyle
 * Description: Developed for the Flight Booking System Repeat CA
 */
 
package ie.lyit.tester;
import ie.lyit.flight.Name;
import java.util.ArrayList;
public class NameTester {

	public static void main(String[] args) {
//		Name me = new Name();
//		me.setFName("Dean");
//		me.setSName("Golding");
//		me.setTitle("Mr");
//		System.out.println(me.toString());
//		Name notme = new Name();
//		notme.setFName("Deane");
//		notme.setSName("Goulding");
//		notme.setTitle("Mrs");
//		System.out.println(notme.toString());
		ArrayList<Name> people = new ArrayList<>();
		people.add(new Name("Mr","Dean","Golding"));
		people.add(new Name("Mrs","Deab","Folding"));
		people.add(new Name("Miss","bdifjd","jkjkjk"));
		for(Name p : people)
		{
			System.out.println(p);
		}
		System.out.println(nameSearch("Dean", people));	
	}
   
	public static boolean nameSearch(String name, ArrayList<Name> people)
	{
		for(Name p : people)
		{
			if (name.equalsIgnoreCase(p.getFName()))
				return true;
			return false;
		}
		return false;
		
	}

}
