/**
 * Author: Dean Golding
 * Class: Software Implementation
 * Instructor: Maria Boyle
 * Description: Developed for the Flight Booking System Repeat CA
 */
 
package ie.lyit.tester;
import ie.lyit.flight.Date;
public class DateTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Date today = new Date(28,5,2019);
		Date tommorow = new Date(28,5,2019);
		System.out.println(today);
		System.out.println(today.equals(tommorow));
		try {
			today.setDay(-1);
		}
		catch(IllegalArgumentException e) {
			System.out.println("Exception : "+ e.getMessage());
		}
	}

}
