/**
 * Author: Dean Golding
 * Class: Software Implementation
 * Instructor: Maria Boyle
 * Description: Developed for the Flight Booking System Repeat CA
 */
package ie.lyit.tester;
import ie.lyit.flight.Employee;
import ie.lyit.flight.Name;
import ie.lyit.serialize.EmployeeSerializer;
import ie.lyit.files.Menu;
import ie.lyit.flight.Date;
import java.util.ArrayList;
public class EmployeeTester {

	public static void main(String[] args) {
		EmployeeSerializer bs = new EmployeeSerializer();
//		bs.add();
//		bs.view(1000);
//		bs.list();
//		bs.serializeEmployees();
		Menu menuObj = new Menu();
		do {
			// Call it's display() method
			menuObj.display();
			// Call it's readOption() method
			
			menuObj.readOption();
	
			// switch on the option and call the appropriate method
			switch(menuObj.getOption()){
			   case 1:bs.add();break;
			   case 2:bs.list();break;
			   case 3:bs.view();break;
			   case 4:bs.edit();break;
			   case 5:bs.delete();break;
			   case 6:break;				
			   default:System.out.println("INVALID OPTION...");
			}
		}while(menuObj.getOption() != 6);
		
		// Write the books ArrayList to File
		// THIS SERIALIZES THE ARRAYLIST		
		bs.serializeEmployees();
		}
    
	public static boolean employeeSearch(Employee employeeSearch, ArrayList<Employee> listOfEmployees){
		return listOfEmployees.contains(employeeSearch);
	}
}