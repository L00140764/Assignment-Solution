/**
 * Author: Dean Golding
 * Class: Software Implementation
 * Instructor: Maria Boyle
 * Description: Developed for the Flight Booking System
 */

package ie.lyit.files;

import java.util.Scanner;
public class Menu {
   private int option;
   public void display(){
    System.out.println("\t1. Add List");
	 System.out.println("\t2. Listings");
	 System.out.println("\t3. View List");
	 System.out.println("\t4. Edit List");
	 System.out.println("\t5. Delete List");
	 System.out.println("\t6. Quit");		
   }
   public void readOption(){
	   Scanner kbInt = new Scanner(System.in);
	  	  System.out.println("\n\tEnter Option [1|2|3|4|5|6]");
	   	option=kbInt.nextInt();
	   	kbInt.nextLine();
   }				
	public int getOption(){
	   return option;
	}	
}