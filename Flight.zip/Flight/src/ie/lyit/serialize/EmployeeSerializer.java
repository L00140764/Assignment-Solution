package ie.lyit.serialize;
import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import ie.lyit.flight.Employee;
import java.util.Scanner;
public class EmployeeSerializer 
{
	private ArrayList<Employee> employees = new ArrayList<Employee>();
	//method to add employees to the employees arrylist
	public void add() 
	{
		Employee employee = new Employee();
		employee.read();
		employees.add(employee);
	}
	//view an employee
	public void view(int empNum) 
	{
		for(Employee b:employees)
		{
			if(empNum==b.getNumber())//i think this should work
			{
				System.out.println(b);
			}
		}
	}
	//delete an employee
	public void delete() 
	{
		Scanner kbIn = new Scanner(System.in);
		int number = kbIn.nextInt();
		for(Employee b:employees)
		{
			if(number==b.getNumber())//i think this should work
			{
				employees.remove(b);
			}
		}
	}
	//TODO create edit method
	
	//does what it says on the tin?
	public void serializeEmployees() 
	{
		try
		{
			ObjectOutputStream os = new ObjectOutputStream(new FileOutputStream("employees.ser"));
			for(Employee b:employees)
			{
				os.writeObject(b);
			}
			os.close();
		}
		catch(FileNotFoundException f)
		{
			 System.out.println("File Not Found" + f.getMessage());
		}
		catch(IOException e)
		{
			e.printStackTrace();
			 System.out.println("Input Output Error: " + e.getMessage());
		}
	}
	//does what it says on the tin?
	public void deserializeEmployees()
	{
		ObjectInputStream is = null;
		try
		{
			FileInputStream fileStream = new FileInputStream("employees.ser");
			is = new ObjectInputStream(fileStream);
			
			//ArrayList<Book> bookListFromFile = new ArrayList<Book>();
			
			ArrayList<Employee> bookListFromFile = (ArrayList<Employee>) is.readObject();
			
			for(Employee b:bookListFromFile)
			{
				
				employees.add(b);
			}
			
			//books = (ArrayList<Book>)is.readObject();
			is.close();
		}
		catch(FileNotFoundException f)
		{
			 System.out.println("File Not Found" + f.getMessage());
		}
		catch(IOException e)
		{
			e.printStackTrace();

			 System.out.println("Input Output Error: " + e.getMessage());
		} 
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (ClassCastException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("ClassCastException Error" + e.getMessage());
		}
//		finally
//		{
//			try
//			{
//				is.close();
//			}
//			catch(IOException e)
//			{
//				System.out.println("I/p O/p Error" + e.getMessage());
//			}
//		}
	}
	public void list() 
	{
		for(Employee b:employees)
		{
			System.out.println(b);
		}
	}
	public void edit() {
		// Call view() to find, display, & return the book to edit
		Employee tempBook = view();
		
		// If the book != null, i.e. it was found then...
	    if(tempBook != null){
		   // get it's index
		   int index=employees.indexOf(tempBook);
		   // read in a new book and...
		   tempBook.read();
		   // reset the object in books
		   employees.set(index, tempBook);
	    }
	}
	public Employee view() {
		Scanner keyboard = new Scanner(System.in);		

		// Read the number of the book to be viewed from the user
		System.out.println("ENTER LIBRARY NUMBER OF BOOK : ");
		int bookToView=keyboard.nextInt();
		
		// for every Book object in books
        for(Employee tmpBook:employees) {
		
  		   // if it's number equals the number of the bookToView
  		   if(tmpBook.getNumber() == bookToView){
  		      // display it and...
  			  System.out.println(tmpBook);
  			  // return it
  			  return tmpBook;
  		   }
        }
  		return null;  
	}
	
}